Rad Dad one page site

Files
1) index.html
2) RadDad_logo.jpg

How to run locally
1) Open index.html in your browser

How to publish fast
1) GitHub Pages
Create a repo, upload both files, enable Pages on main branch

2) Netlify
Drag and drop the folder into Netlify deploy

Edit links and video
Open index.html and find the LINKS and VIDEO sections near the top of the script
